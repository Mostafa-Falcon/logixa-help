import type { Metadata } from 'next'
import Link from 'next/link'
import { HiChevronLeft, HiHome } from 'react-icons/hi'

export const metadata: Metadata = {
  title: 'شروط الاستخدام',
}

export default function TermsPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-4">
      <div className="flex items-center gap-2 text-xs mb-4" style={{ color: '#6e8b9e' }}>
        <Link href="/" style={{ color: '#6e8b9e' }}><HiHome className="inline" /> الرئيسية</Link>
        <HiChevronLeft className="text-xs" />
        <span style={{ color: '#c8d5de' }}>شروط الاستخدام</span>
      </div>

      <div className="block-container">
        <div className="block-header">شروط الاستخدام</div>
        <div className="p-4 text-sm leading-relaxed prose-content" style={{ color: '#c8d5de' }}>
          <h2>القبول</h2>
          <p>
            باستخدامك Logixa Help، أنت توافق على شروط الاستخدام هذه. إذا كنت لا توافق، يرجى عدم استخدام المنصة.
          </p>

          <h2>المحتوى</h2>
          <p>
            أنت المسؤول الوحيد عن المحتوى الذي تنشره. يجب ألا ينتهك المحتوى حقوق الآخرين أو القوانين المعمول بها.
          </p>

          <h2>السلوك</h2>
          <p>عند استخدام المنصة، أنت توافق على:</p>
          <ul>
            <li>عدم نشر محتوى مسيء أو غير قانوني</li>
            <li>عدم التحرش بالآخرين</li>
            <li>عدم نشر سبام أو روابط ضارة</li>
            <li>عدم انتحال شخصية الآخرين</li>
            <li>احترام آراء الآخرين</li>
          </ul>

          <h2>الحسابات</h2>
          <p>
            أنت مسؤول عن الحفاظ على سرية حسابك وكلمة السر. يجب إبلاغنا فورًا عن أي استخدام غير مصرح به.
          </p>

          <h2>الملكية الفكرية</h2>
          <p>
            المحتوى الذي تنشره يبقى ملكك. بمنشره على المنصة، تمنحنا ترخيصًا غير حصري لعرضه وتوزيعه على المنصة.
          </p>

          <h2>إخلاء المسؤولية</h2>
          <p>
            نقدم المنصة &quot;كما هي&quot; بدون ضمانات. لسنا مسؤولين عن أي أضرار ناتجة عن استخدام المنصة.
          </p>

          <h2>التعديلات</h2>
          <p>
            قد نقوم بتعديل هذه الشروط من وقت لآخر. استمرار استخدام المنصة بعد التعديلات يعني موافقتك على الشروط المعدلة.
          </p>
        </div>
      </div>
    </div>
  )
}
