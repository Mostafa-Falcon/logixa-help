import type { Metadata } from "next"
import "./globals.css"
import Header from "@/components/Header"
import Footer from "@/components/Footer"

export const metadata: Metadata = {
  title: {
    default: "Logixa Help — منصة الأسئلة والإجابات التقنية",
    template: "%s — Logixa Help",
  },
  description: "منصة عربية للأسئلة والإجابات التقنية. حلول لمشاكل الكمبيوتر، الموبايل، البرمجة، الذكاء الاصطناعي، والمشاريع الصغيرة.",
  openGraph: {
    title: "Logixa Help — منصة الأسئلة والإجابات التقنية",
    description: "منصة عربية للأسئلة والإجابات التقنية. حلول لمشاكل الكمبيوتر، الموبايل، البرمجة، الذكاء الاصطناعي، والمشاريع الصغيرة.",
    type: "website",
    locale: "ar_AR",
    siteName: "Logixa Help",
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className="h-full">
      <body className="h-full flex flex-col">
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  )
}
