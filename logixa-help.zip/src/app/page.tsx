import Link from 'next/link'
import { HiChevronLeft, HiSearch } from 'react-icons/hi'

import { createServerSupabaseClient } from '@/lib/supabase-server'
import type { Category } from '@/lib/types'

export const dynamic = 'force-dynamic'

export default async function HomePage() {
  const supabase = await createServerSupabaseClient()

  const { data: categories } = await supabase
    .from('categories')
    .select('*')
    .order('sort_order')
    .returns<Category[]>()

  const { count: totalThreads } = await supabase
    .from('threads')
    .select('*', { count: 'exact', head: true })

  const { count: totalReplies } = await supabase
    .from('replies')
    .select('*', { count: 'exact', head: true })

  const { count: totalUsers } = await supabase
    .from('profiles')
    .select('*', { count: 'exact', head: true })

  const { data: latestUser } = await supabase
    .from('profiles')
    .select('username')
    .order('created_at', { ascending: false })
    .limit(1)
    .single()

  return (
    <div className="max-w-6xl mx-auto px-4 py-4">
      <div className="flex items-center justify-between mb-4 text-xs" style={{ color: '#6e8b9e' }}>
        <div className="flex items-center gap-4 flex-wrap">
          <span>المواضيع: <strong style={{ color: '#c8d5de' }}>{totalThreads ?? 0}</strong></span>
          <span>الردود: <strong style={{ color: '#c8d5de' }}>{totalReplies ?? 0}</strong></span>
          <span>الأعضاء: <strong style={{ color: '#c8d5de' }}>{totalUsers ?? 0}</strong></span>
        </div>
        {latestUser && (
          <span>آخر عضو: <strong style={{ color: '#d4a843' }}>{latestUser.username}</strong></span>
        )}
      </div>

      <div className="block-container mb-4">
        <div className="block-header">
          <span className="flex items-center gap-1.5">
            <span style={{ color: '#d4a843' }}>●</span>
            <span>مرحبًا بك في Logixa Help</span>
          </span>
        </div>
        <div className="p-4 text-sm leading-relaxed" style={{ color: '#6e8b9e' }}>
          منصة الأسئلة والإجابات التقنية. اسأل عن أي مشكلة تقنية واحصل على حلول من المجتمع.
          <div className="flex items-center gap-3 mt-3 flex-wrap">
            <Link href="/search" className="btn btn-outline text-xs">
              <HiSearch /> ابحث عن حل
            </Link>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-4">
        {(categories ?? []).map((cat) => (
          <div key={cat.id} className="block-container">
            <Link
              href={`/c/${cat.slug}`}
              className="block-header flex items-center justify-between no-underline hover:brightness-110 transition"
            >
              <div className="flex items-center gap-2">
                <span>{cat.icon}</span>
                <span>{cat.name}</span>
                <span className="text-xs font-normal" style={{ color: '#6e8b9e' }}>
                  — {cat.description}
                </span>
              </div>
              <HiChevronLeft className="text-xs" style={{ color: '#6e8b9e' }} />
            </Link>
            <div className="node-body">
              <div className="node-icon">{cat.icon}</div>
              <div className="node-main">
                <div className="node-title">
                  <Link href={`/c/${cat.slug}`}>{cat.name}</Link>
                </div>
                <div className="node-desc">{cat.description}</div>
                <div className="node-stats-row">
                  <span>المواضيع: <strong>{cat.threads_count}</strong></span>
                  <span>الردود: <strong>{cat.replies_count}</strong></span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {(!categories || categories.length === 0) && (
        <div className="block-container text-center py-8">
          <div className="text-xl mb-2">💭</div>
          <div className="text-sm" style={{ color: '#6e8b9e' }}>
            الموقع تحت الإعداد. قريبًا نفتتح الأقسام.
          </div>
        </div>
      )}
    </div>
  )
}
