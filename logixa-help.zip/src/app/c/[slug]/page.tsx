import Link from 'next/link'
import { notFound } from 'next/navigation'
import { HiChat, HiChevronLeft, HiHome, HiPencil } from 'react-icons/hi'

import { createServerSupabaseClient } from '@/lib/supabase-server'
import type { Category, Thread } from '@/lib/types'

export const dynamic = 'force-dynamic'

type CategoryThread = Thread & {
  author: { username: string; avatar_url: string } | null
}

export default async function CategoryPage({
  params,
}: {
  params: Promise<{ slug: string }>
}) {
  const { slug } = await params
  const supabase = await createServerSupabaseClient()

  const { data: category } = await supabase
    .from('categories')
    .select('*')
    .eq('slug', slug)
    .single()

  if (!category) {
    notFound()
  }

  const cat = category as Category

  const { data: threads } = await supabase
    .from('threads')
    .select('*, author:author_id(username, avatar_url)')
    .eq('category_id', cat.id)
    .eq('status', 'published')
    .order('is_pinned', { ascending: false })
    .order('created_at', { ascending: false })
    .returns<CategoryThread[]>()

  return (
    <div className="max-w-6xl mx-auto px-4 py-4">
      <div className="flex items-center gap-2 text-xs mb-4" style={{ color: '#6e8b9e' }}>
        <Link href="/" style={{ color: '#6e8b9e' }}><HiHome className="inline" /> الرئيسية</Link>
        <HiChevronLeft className="text-xs" />
        <span style={{ color: '#c8d5de' }}>{cat.name}</span>
      </div>

      <div className="block-container mb-4">
        <div className="block-header flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span>{cat.icon}</span>
            <span>{cat.name}</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs" style={{ color: '#6e8b9e' }}>
              {cat.threads_count} مواضيع
            </span>
            <Link href={`/t/new?cat=${cat.id}`} className="btn btn-primary text-xs py-1 px-3">
              <HiPencil /> سؤال جديد
            </Link>
          </div>
        </div>
        <div className="px-3 py-2 text-xs" style={{ color: '#6e8b9e' }}>
          {cat.description}
        </div>
      </div>

      {!threads || threads.length === 0 ? (
        <div className="block-container text-center py-8">
          <div className="text-2xl mb-2">💭</div>
          <div className="text-sm" style={{ color: '#6e8b9e' }}>
            مافيش أسئلة في القسم ده لسه. كن أول من يسأل.
          </div>
          <Link href={`/t/new?cat=${cat.id}`} className="btn btn-primary text-xs mt-3 inline-flex">
            <HiPencil /> اكتب سؤال
          </Link>
        </div>
      ) : (
        <div className="block-container">
          {threads.map((thread, index) => (
            <div
              key={thread.id}
              className={`node ${index < threads.length - 1 ? 'border-b' : ''}`}
              style={{ borderColor: '#163e54' }}
            >
              <Link href={`/t/${thread.slug}`} className="node-body no-underline">
                <div className="node-icon">
                  {thread.is_pinned ? <span>📌</span> : <HiChat />}
                </div>
                <div className="node-main">
                  <div className="node-title flex items-center gap-2">
                    <span>{thread.title}</span>
                    {thread.is_pinned && (
                      <span
                        className="text-[10px] font-medium px-1.5 py-0.5 rounded"
                        style={{ background: 'rgba(15,87,138,0.3)', color: '#1e8bc3' }}
                      >
                        مثبت
                      </span>
                    )}
                  </div>
                  <div className="node-stats-row">
                    <span>بواسطة <strong>{thread.author?.username ?? 'مجهول'}</strong></span>
                    <span>
                      {new Date(thread.created_at).toLocaleDateString('ar-EG', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </span>
                  </div>
                </div>
                <div className="node-stats-col">
                  <dd>{thread.views}</dd>
                  <dt>مشاهدة</dt>
                </div>
                <div className="node-stats-col">
                  <dd>{thread.replies_count}</dd>
                  <dt>ردود</dt>
                </div>
              </Link>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
