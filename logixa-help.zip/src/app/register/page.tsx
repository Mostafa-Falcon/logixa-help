'use client'

import Link from 'next/link'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { HiUserAdd } from 'react-icons/hi'

export default function RegisterPage() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [sending, setSending] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setSending(true)
    setError('')
    setNotice('')

    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, username }),
    })
    const data = await res.json()

    if (data.error) {
      setError(data.error)
      setSending(false)
      return
    }

    if (data.needsEmailConfirmation) {
      setNotice('تم إنشاء الحساب. راجع بريدك الإلكتروني لتأكيد الحساب ثم سجّل دخول.')
      setSending(false)
      router.push(data.redirectTo || '/login')
      return
    }

    router.push(data.redirectTo || '/')
    router.refresh()
  }

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-sm">
        <div className="block-container">
          <div className="block-header flex items-center justify-center gap-2">
            <HiUserAdd /> تسجيل جديد
          </div>
          <div className="p-6">
            <p className="text-xs mb-5 text-center" style={{ color: '#6e8b9e' }}>
              انضم لينا وشارك أسئلتك
            </p>
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <div className="text-xs p-2 rounded" style={{ background: 'rgba(239,68,68,0.1)', color: '#ef4444' }}>
                  {error}
                </div>
              )}
              {notice && (
                <div className="text-xs p-2 rounded" style={{ background: 'rgba(34,197,94,0.1)', color: '#22c55e' }}>
                  {notice}
                </div>
              )}
              <div>
                <label className="block text-xs mb-1" style={{ color: '#c8d5de' }}>اسم المستخدم</label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  className="form-input"
                />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: '#c8d5de' }}>البريد الإلكتروني</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="form-input"
                  placeholder="example@email.com"
                />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: '#c8d5de' }}>كلمة السر</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="form-input"
                />
              </div>
              <button type="submit" disabled={sending} className="btn btn-primary w-full justify-center mt-2">
                {sending ? 'جاري التسجيل...' : 'تسجيل'}
              </button>
            </form>
            <p className="text-xs text-center mt-5" style={{ color: '#6e8b9e' }}>
              عندك حساب؟{' '}
              <Link href="/login" style={{ color: '#1e8bc3' }}>ادخل من هنا</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
