import type { Metadata } from 'next'
import { HiHome, HiChevronLeft } from 'react-icons/hi'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'سياسة الخصوصية',
}

export default function PrivacyPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-4">
      <div className="flex items-center gap-2 text-xs mb-4" style={{ color: '#6e8b9e' }}>
        <Link href="/" style={{ color: '#6e8b9e' }}><HiHome className="inline" /> الرئيسية</Link>
        <HiChevronLeft className="text-xs" />
        <span style={{ color: '#c8d5de' }}>سياسة الخصوصية</span>
      </div>

      <div className="block-container">
        <div className="block-header">سياسة الخصوصية</div>
        <div className="p-4 text-sm leading-relaxed prose-content" style={{ color: '#c8d5de' }}>
          <h2>المقدمة</h2>
          <p>
            في Logixa Help، خصوصيتك مهمة بالنسبة لنا. توضح سياسة الخصوصية هذه كيفية جمع واستخدام وحماية معلوماتك الشخصية.
          </p>

          <h2>المعلومات التي نجمعها</h2>
          <ul>
            <li>معلومات الحساب: الاسم، البريد الإلكتروني، اسم المستخدم</li>
            <li>المحتوى الذي تنشره: الأسئلة، الإجابات، التعليقات</li>
            <li>بيانات الاستخدام: الصفحات التي تزورها، الوقت، المتصفح</li>
          </ul>

          <h2>كيف نستخدم معلوماتك</h2>
          <ul>
            <li>تقديم وتحسين خدمات المنصة</li>
            <li>التواصل معك بخصوص حسابك</li>
            <li>تحليل استخدام المنصة لتحسين التجربة</li>
            <li>عرض إعلانات مخصصة (عند تفعيل AdSense)</li>
          </ul>

          <h2>ملفات تعريف الارتباط (Cookies)</h2>
          <p>
            نستخدم ملفات تعريف الارتباط لتحسين تجربتك. قد تستخدم أطراف ثالثة مثل Google AdSense ملفات تعريف الارتباط لعرض إعلانات مخصصة.
          </p>

          <h2>مشاركة المعلومات</h2>
          <p>
            لا نشارك معلوماتك الشخصية مع أطراف ثالثة إلا في الحالات التالية:
          </p>
          <ul>
            <li>بموجب القانون</li>
            <li>لحماية حقوقنا</li>
            <li>مع موفري الخدمات الذين يساعدوننا في تشغيل المنصة</li>
          </ul>

          <h2>الأمان</h2>
          <p>
            نستخدم إجراءات أمان معيارية لحماية معلوماتك. ومع ذلك، لا يمكن ضمان أمان مطلق للبيانات المنقولة عبر الإنترنت.
          </p>

          <h2>حقوقك</h2>
          <p>لديك الحق في:</p>
          <ul>
            <li>الوصول إلى بياناتك الشخصية</li>
            <li>طلب تصحيح أو حذف بياناتك</li>
            <li>إلغاء الاشتراك في الاتصالات التسويقية</li>
          </ul>

          <h2>التعديلات</h2>
          <p>
            قد نقوم بتحديث سياسة الخصوصية هذه من وقت لآخر. سنقوم بإعلامك بأي تغييرات جوهرية.
          </p>

          <h2>اتصل بنا</h2>
          <p>
            لأي استفسار بخصوص سياسة الخصوصية، يرجى التواصل عبر البريد الإلكتروني.
          </p>
        </div>
      </div>
    </div>
  )
}
