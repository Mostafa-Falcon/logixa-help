'use client'

import Link from 'next/link'
import { Suspense, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { HiLogin } from 'react-icons/hi'

function LoginForm() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [sending, setSending] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setSending(true)
    setError('')

    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    })
    const data = await res.json()

    if (data.error) {
      setError(data.error)
      setSending(false)
      return
    }

    router.push(searchParams.get('next') || data.redirectTo || '/')
    router.refresh()
  }

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-sm">
        <div className="block-container">
          <div className="block-header flex items-center justify-center gap-2">
            <HiLogin /> دخول
          </div>
          <div className="p-6">
            <p className="text-xs mb-5 text-center" style={{ color: '#6e8b9e' }}>
              ادخل عشان تشارك وتتفاعل
            </p>
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <div className="text-xs p-2 rounded" style={{ background: 'rgba(239,68,68,0.1)', color: '#ef4444' }}>
                  {error}
                </div>
              )}
              <div>
                <label className="block text-xs mb-1" style={{ color: '#c8d5de' }}>البريد الإلكتروني</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="form-input"
                  placeholder="example@email.com"
                />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: '#c8d5de' }}>كلمة السر</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="form-input"
                />
              </div>
              <button type="submit" disabled={sending} className="btn btn-primary w-full justify-center mt-2">
                {sending ? 'جاري الدخول...' : 'دخول'}
              </button>
            </form>
            <p className="text-xs text-center mt-5" style={{ color: '#6e8b9e' }}>
              مش عندك حساب؟{' '}
              <Link href="/register" style={{ color: '#1e8bc3' }}>سجل دلوقتي</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function LoginPage() {
  return (
    <Suspense fallback={(
      <div className="min-h-[70vh] flex items-center justify-center px-4 py-12">
        <div className="block-container w-full max-w-sm text-center py-8">
          <div className="text-sm" style={{ color: '#6e8b9e' }}>جاري التحميل...</div>
        </div>
      </div>
    )}
    >
      <LoginForm />
    </Suspense>
  )
}
