import Link from 'next/link'
import { HiChevronLeft, HiHome, HiSearch } from 'react-icons/hi'

import { createServerSupabaseClient } from '@/lib/supabase-server'
import type { Thread } from '@/lib/types'

export const dynamic = 'force-dynamic'

type SearchThread = Thread & {
  author: { username: string } | null
}

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>
}) {
  const { q } = await searchParams
  const supabase = await createServerSupabaseClient()
  let threads: SearchThread[] = []

  if (q) {
    const { data } = await supabase
      .from('threads')
      .select('*, author:author_id(username)')
      .eq('status', 'published')
      .ilike('title', `%${q}%`)
      .order('created_at', { ascending: false })
      .limit(50)
      .returns<SearchThread[]>()

    threads = data ?? []
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-4">
      <div className="flex items-center gap-2 text-xs mb-4" style={{ color: '#6e8b9e' }}>
        <Link href="/" style={{ color: '#6e8b9e' }}><HiHome className="inline" /> الرئيسية</Link>
        <HiChevronLeft className="text-xs" />
        <span style={{ color: '#c8d5de' }}>بحث</span>
      </div>

      <div className="block-container mb-4">
        <div className="block-header flex items-center gap-2">
          <HiSearch />
          <span>ابحث عن حل</span>
        </div>
        <div className="p-4">
          <form className="flex gap-3">
            <input
              type="text"
              name="q"
              defaultValue={q ?? ''}
              placeholder="ابحث عن مشكلة أو حل..."
              className="form-input flex-1"
            />
            <button type="submit" className="btn btn-primary">بحث</button>
          </form>
        </div>
      </div>

      {q && (
        <div className="block-container">
          <div className="block-header">
            نتائج البحث عن: &quot;{q}&quot; ({threads.length})
          </div>
          {threads.length === 0 ? (
            <div className="p-4 text-sm" style={{ color: '#6e8b9e' }}>
              مافيش نتائج. جرب كلمات بحث مختلفة.
            </div>
          ) : (
            <div>
              {threads.map((thread, index) => (
                <Link
                  key={thread.id}
                  href={`/t/${thread.slug}`}
                  className="node block no-underline"
                  style={{ borderBottom: index < threads.length - 1 ? '1px solid #163e54' : 'none' }}
                >
                  <div className="node-body">
                    <div className="node-icon">📄</div>
                    <div className="node-main">
                      <div className="node-title">{thread.title}</div>
                      <div className="node-stats-row">
                        <span>{thread.author?.username ?? 'مجهول'}</span>
                        <span>{thread.replies_count} ردود</span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
