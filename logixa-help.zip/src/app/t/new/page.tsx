'use client'

import Link from 'next/link'
import { Suspense, useEffect, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { HiChevronLeft, HiHome } from 'react-icons/hi'

import { createBrowserSupabaseClient } from '@/lib/supabase'
import type { Category } from '@/lib/types'

function NewThreadForm() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const supabase = createBrowserSupabaseClient()
  const [categories, setCategories] = useState<Category[]>([])
  const [categoryId, setCategoryId] = useState(searchParams.get('cat') || '')
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')
  const [error, setError] = useState('')
  const [sending, setSending] = useState(false)

  useEffect(() => {
    async function loadCategories() {
      const { data } = await supabase.from('categories').select('*').order('sort_order')
      if (data) {
        setCategories(data)
      }
    }

    loadCategories()
  }, [supabase])

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setSending(true)
    setError('')

    const res = await fetch('/api/threads', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ category_id: Number(categoryId), title, body }),
    })
    const data = await res.json()

    if (data.error) {
      setError(data.error)
      setSending(false)
      return
    }

    if (data.slug) {
      router.push(`/t/${data.slug}`)
    }
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-4">
      <div className="flex items-center gap-2 text-xs mb-4" style={{ color: '#6e8b9e' }}>
        <Link href="/" style={{ color: '#6e8b9e' }}><HiHome className="inline" /> الرئيسية</Link>
        <HiChevronLeft className="text-xs" />
        <span style={{ color: '#c8d5de' }}>سؤال جديد</span>
      </div>

      <div className="block-container">
        <div className="block-header">سؤال جديد</div>
        <div className="p-4">
          {error && (
            <div className="text-xs p-2 rounded mb-4" style={{ background: 'rgba(239,68,68,0.1)', color: '#ef4444' }}>
              {error}
            </div>
          )}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs mb-1 font-medium" style={{ color: '#c8d5de' }}>القسم</label>
              <select
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
                required
                className="form-input"
              >
                <option value="">اختر القسم...</option>
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>{category.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs mb-1 font-medium" style={{ color: '#c8d5de' }}>العنوان</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                className="form-input"
                placeholder="مثال: إزاي أحل مشكلة تعليق ويندوز 11؟"
              />
            </div>
            <div>
              <label className="block text-xs mb-1 font-medium" style={{ color: '#c8d5de' }}>شرح المشكلة</label>
              <textarea
                value={body}
                onChange={(e) => setBody(e.target.value)}
                required
                rows={10}
                className="form-input resize-y"
                placeholder="اشرح مشكلتك بالتفصيل... ماذا حدث؟ ماذا جربت؟ ما هي الأخطاء؟"
              />
            </div>
            <div className="flex items-center gap-3 pt-2">
              <button type="submit" disabled={sending} className="btn btn-primary">
                {sending ? 'جاري النشر...' : 'نشر السؤال'}
              </button>
              <button type="button" onClick={() => router.back()} className="btn btn-outline">
                إلغاء
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

export default function NewThreadPage() {
  return (
    <Suspense fallback={(
      <div className="max-w-4xl mx-auto px-4 py-4">
        <div className="block-container text-center py-8">
          <div className="text-sm" style={{ color: '#6e8b9e' }}>جاري التحميل...</div>
        </div>
      </div>
    )}
    >
      <NewThreadForm />
    </Suspense>
  )
}
