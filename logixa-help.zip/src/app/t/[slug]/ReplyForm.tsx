'use client'

import Link from 'next/link'
import { useState } from 'react'
import { useRouter } from 'next/navigation'

export default function ReplyForm({ threadId }: { threadId: number }) {
  const router = useRouter()
  const [content, setContent] = useState('')
  const [error, setError] = useState('')
  const [sending, setSending] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setSending(true)
    setError('')

    const res = await fetch('/api/replies', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ thread_id: threadId, body: content }),
    })
    const data = await res.json()

    if (data.error) {
      setError(data.error)
      setSending(false)
      return
    }

    setContent('')
    setSending(false)
    router.refresh()
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      {error && (
        <div className="text-xs p-2 rounded" style={{ background: 'rgba(239,68,68,0.1)', color: '#ef4444' }}>
          {error}
          {error.includes('تسجيل الدخول') && (
            <>
              {' '}
              <Link href="/login" style={{ color: '#1e8bc3' }}>ادخل من هنا</Link>
            </>
          )}
        </div>
      )}
      <div className="flex gap-3">
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          required
          rows={3}
          className="form-input flex-1 resize-y text-sm"
          placeholder="اكتب إجابتك..."
        />
        <button
          type="submit"
          disabled={sending}
          className="btn btn-primary self-end px-4 py-2"
        >
          {sending ? '...' : 'إجابة'}
        </button>
      </div>
    </form>
  )
}
