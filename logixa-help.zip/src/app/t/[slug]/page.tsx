import Link from 'next/link'
import { notFound } from 'next/navigation'
import { HiChat, HiChevronLeft, HiEye, HiHome } from 'react-icons/hi'

import { createServerSupabaseClient } from '@/lib/supabase-server'
import type { Reply, Thread } from '@/lib/types'

import ReplyForm from './ReplyForm'

export const dynamic = 'force-dynamic'

type ThreadDetails = Thread & {
  author: { username: string; avatar_url: string } | null
  category: { name: string; slug: string } | null
}

type ThreadReply = Reply & {
  author: { username: string; avatar_url: string } | null
}

export default async function ThreadPage({
  params,
}: {
  params: Promise<{ slug: string }>
}) {
  const { slug } = await params
  const supabase = await createServerSupabaseClient()

  const { data: threadData } = await supabase
    .from('threads')
    .select('*, author:author_id(username, avatar_url), category:category_id(name, slug)')
    .eq('slug', slug)
    .single()

  if (!threadData) {
    notFound()
  }

  const thread = threadData as ThreadDetails

  await supabase.rpc('increment_thread_views', { thread_id: thread.id })

  const { data: replies } = await supabase
    .from('replies')
    .select('*, author:author_id(username, avatar_url)')
    .eq('thread_id', thread.id)
    .eq('status', 'visible')
    .order('created_at', { ascending: true })
    .returns<ThreadReply[]>()

  return (
    <div className="max-w-5xl mx-auto px-4 py-4">
      <div className="flex items-center gap-2 text-xs mb-4" style={{ color: '#6e8b9e' }}>
        <Link href="/" style={{ color: '#6e8b9e' }}><HiHome className="inline" /> الرئيسية</Link>
        <HiChevronLeft className="text-xs" />
        {thread.category && (
          <>
            <Link href={`/c/${thread.category.slug}`} style={{ color: '#6e8b9e' }}>
              {thread.category.name}
            </Link>
            <HiChevronLeft className="text-xs" />
          </>
        )}
        <span className="truncate max-w-[250px]" style={{ color: '#c8d5de' }}>{thread.title}</span>
      </div>

      <div className="block-container mb-4">
        <div className="block-header flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span>{thread.is_pinned ? '📌' : '📄'}</span>
            <span>{thread.title}</span>
          </div>
          <div className="flex items-center gap-3 text-xs" style={{ color: '#6e8b9e' }}>
            <span><HiEye className="inline" /> {thread.views}</span>
            <span><HiChat className="inline" /> {thread.replies_count}</span>
          </div>
        </div>
        <div
          className="px-4 py-2 text-xs border-b flex items-center gap-2"
          style={{ color: '#6e8b9e', borderColor: '#163e54' }}
        >
          <span
            className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold"
            style={{ background: '#0f578a', color: '#fff' }}
          >
            {(thread.author?.username ?? '?')[0]}
          </span>
          <strong style={{ color: '#c8d5de' }}>{thread.author?.username ?? 'مجهول'}</strong>
          <span>—</span>
          <span>
            {new Date(thread.created_at).toLocaleDateString('ar-EG', {
              day: 'numeric',
              month: 'long',
              year: 'numeric',
            })}
          </span>
        </div>
        <div className="p-4 text-sm leading-relaxed whitespace-pre-line prose-content" style={{ color: '#c8d5de' }}>
          {thread.body}
        </div>
      </div>

      <div className="block-container mb-4">
        <div className="block-header">
          الردود ({replies?.length ?? 0})
        </div>
        {!replies || replies.length === 0 ? (
          <div className="text-center py-6">
            <div className="text-xl mb-2">💬</div>
            <div className="text-sm" style={{ color: '#6e8b9e' }}>مافيش ردود لسه. كن أول من يجاوب.</div>
          </div>
        ) : (
          <div>
            {replies.map((reply, index) => (
              <div key={reply.id} className="node">
                <div className="p-3">
                  <div
                    className="flex items-center justify-between mb-2 pb-2 border-b"
                    style={{ borderColor: '#163e54' }}
                  >
                    <div className="flex items-center gap-2 text-xs">
                      <span
                        className="w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-bold"
                        style={{ background: '#0f578a', color: '#fff' }}
                      >
                        {(reply.author?.username ?? '?')[0]}
                      </span>
                      <span className="font-medium" style={{ color: '#c8d5de' }}>
                        {reply.author?.username ?? 'مجهول'}
                      </span>
                      <span style={{ color: '#6e8b9e' }}>
                        {new Date(reply.created_at).toLocaleDateString('ar-EG', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </span>
                      {reply.is_best_answer && (
                        <span
                          className="text-[10px] px-1.5 py-0.5 rounded"
                          style={{ background: 'rgba(34,197,94,0.15)', color: '#22c55e' }}
                        >
                          ✓ أفضل إجابة
                        </span>
                      )}
                    </div>
                    <span className="text-xs" style={{ color: '#3e5a6b' }}>#{index + 1}</span>
                  </div>
                  <p className="text-sm leading-relaxed whitespace-pre-line" style={{ color: '#c8d5de' }}>
                    {reply.body}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="block-container">
        <div className="block-header">أضف إجابة</div>
        <div className="p-4">
          <ReplyForm threadId={thread.id} />
        </div>
      </div>
    </div>
  )
}
