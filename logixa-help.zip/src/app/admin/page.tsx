import Link from 'next/link'
import { redirect } from 'next/navigation'
import { HiChartBar, HiDocumentText, HiEye } from 'react-icons/hi'

import { getCurrentUserWithProfile } from '@/lib/auth'
import { createServerSupabaseClient } from '@/lib/supabase-server'
import type { Thread } from '@/lib/types'

export const dynamic = 'force-dynamic'

export default async function AdminPage() {
  const { user, profile } = await getCurrentUserWithProfile()

  if (!user) {
    redirect('/login?next=/admin')
  }

  if (profile?.role !== 'admin') {
    redirect('/')
  }

  const supabase = await createServerSupabaseClient()

  const { count: totalUsers } = await supabase
    .from('profiles')
    .select('*', { count: 'exact', head: true })

  const { count: totalThreads } = await supabase
    .from('threads')
    .select('*', { count: 'exact', head: true })

  const { count: totalReplies } = await supabase
    .from('replies')
    .select('*', { count: 'exact', head: true })

  const { data: threads } = await supabase
    .from('threads')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(20)
    .returns<Thread[]>()

  return (
    <div className="max-w-6xl mx-auto px-4 py-4">
      <div className="flex items-center gap-2 mb-4">
        <HiChartBar className="text-lg" style={{ color: '#d4a843' }} />
        <h1 className="text-lg font-bold" style={{ color: '#c8d5de' }}>لوحة التحكم</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="block-container">
          <div className="p-4">
            <p className="text-xs" style={{ color: '#6e8b9e' }}>الأعضاء</p>
            <p className="text-2xl font-bold mt-1" style={{ color: '#c8d5de' }}>{totalUsers ?? 0}</p>
          </div>
        </div>
        <div className="block-container">
          <div className="p-4">
            <p className="text-xs" style={{ color: '#6e8b9e' }}>المواضيع</p>
            <p className="text-2xl font-bold mt-1" style={{ color: '#c8d5de' }}>{totalThreads ?? 0}</p>
          </div>
        </div>
        <div className="block-container">
          <div className="p-4">
            <p className="text-xs" style={{ color: '#6e8b9e' }}>الردود</p>
            <p className="text-2xl font-bold mt-1" style={{ color: '#c8d5de' }}>{totalReplies ?? 0}</p>
          </div>
        </div>
      </div>

      <div className="block-container">
        <div className="block-header flex items-center gap-2">
          <HiDocumentText />
          آخر المواضيع
        </div>
        {!threads || threads.length === 0 ? (
          <div className="p-4 text-sm" style={{ color: '#6e8b9e' }}>مفيش مواضيع</div>
        ) : (
          <div>
            {threads.map((thread, index) => (
              <Link
                key={thread.id}
                href={`/t/${thread.slug}`}
                className="node block no-underline"
                style={{ borderBottom: index < threads.length - 1 ? '1px solid #163e54' : 'none' }}
              >
                <div className="node-body">
                  <div className="node-icon">{thread.is_pinned ? '📌' : '📄'}</div>
                  <div className="node-main">
                    <div className="node-title">{thread.title}</div>
                    <div className="node-stats-row">
                      <span>الردود: {thread.replies_count}</span>
                      <span><HiEye className="inline" /> {thread.views}</span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
