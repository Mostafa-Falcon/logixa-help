'use client'

import Link from 'next/link'
import { useEffect, useState } from 'react'
import { usePathname, useRouter } from 'next/navigation'
import { HiHome, HiLogin, HiLogout, HiMenu, HiPlusCircle, HiSearch, HiUserAdd, HiX } from 'react-icons/hi'

type HeaderUser = {
  username: string
  role: 'member' | 'trusted' | 'moderator' | 'admin'
}

export default function Header() {
  const pathname = usePathname()
  const router = useRouter()
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [user, setUser] = useState<HeaderUser | null>(null)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    async function loadUser() {
      const res = await fetch('/api/users', { cache: 'no-store' })
      if (!res.ok) {
        setUser(null)
        return
      }

      const data = await res.json()
      if (data.profile?.username) {
        setUser({
          username: data.profile.username,
          role: data.profile.role,
        })
      }
    }

    loadUser()
  }, [pathname])

  async function handleLogout() {
    const res = await fetch('/api/auth/logout', { method: 'POST' })
    if (!res.ok) {
      return
    }

    setUser(null)
    router.refresh()
    router.push('/')
  }

  return (
    <header
      className="sticky top-0 z-50 transition-all duration-300"
      style={{
        background: '#0a1c29',
        borderBottom: '1px solid #163e54',
        boxShadow: scrolled ? '0 2px 12px rgba(0,0,0,0.3)' : 'none',
      }}
    >
      <div className="max-w-6xl mx-auto px-4 h-12 flex items-center justify-between gap-4">
        <Link href="/" className="flex items-center gap-2 group">
          <span className="text-lg font-extrabold tracking-tight">
            <span style={{ color: '#d4a843' }}>Logixa</span>
            <span style={{ color: '#c8d5de' }}> Help</span>
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-1">
          <Link href="/" className="flex items-center gap-1.5 px-3 py-1.5 text-sm rounded" style={{ color: '#6e8b9e' }}>
            <HiHome className="text-base" /> الرئيسية
          </Link>
          <Link href="/search" className="flex items-center gap-1.5 px-3 py-1.5 text-sm rounded" style={{ color: '#6e8b9e' }}>
            <HiSearch className="text-base" /> بحث
          </Link>
          <Link href="/t/new" className="flex items-center gap-1.5 px-3 py-1.5 text-sm rounded" style={{ color: '#6e8b9e' }}>
            <HiPlusCircle className="text-base" /> سؤال جديد
          </Link>

          {user ? (
            <>
              {user.role === 'admin' && (
                <Link
                  href="/admin"
                  className="flex items-center gap-1.5 px-3 py-1.5 text-sm rounded"
                  style={{ color: '#d4a843' }}
                >
                  لوحة التحكم
                </Link>
              )}
              <span className="px-3 py-1.5 text-sm" style={{ color: '#c8d5de' }}>
                {user.username}
              </span>
              <button
                type="button"
                onClick={handleLogout}
                className="flex items-center gap-1.5 px-3 py-1.5 text-sm rounded"
                style={{ color: '#6e8b9e' }}
              >
                <HiLogout className="text-base" /> خروج
              </button>
            </>
          ) : (
            <>
              <Link href="/login" className="flex items-center gap-1.5 px-3 py-1.5 text-sm rounded" style={{ color: '#6e8b9e' }}>
                <HiLogin className="text-base" /> دخول
              </Link>
              <Link
                href="/register"
                className="flex items-center gap-1.5 px-4 py-1.5 text-sm rounded font-medium"
                style={{ background: '#0f578a', color: '#fff' }}
              >
                <HiUserAdd className="text-base" /> تسجيل
              </Link>
            </>
          )}
        </div>

        <button
          className="md:hidden p-2 rounded"
          style={{ color: '#6e8b9e' }}
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? <HiX className="text-xl" /> : <HiMenu className="text-xl" />}
        </button>
      </div>

      {menuOpen && (
        <div className="md:hidden border-t px-4 py-2" style={{ background: '#0b2637', borderColor: '#163e54' }}>
          <div className="flex flex-col gap-1">
            <Link href="/" className="py-1.5 text-sm" style={{ color: '#6e8b9e' }}>الرئيسية</Link>
            <Link href="/search" className="py-1.5 text-sm" style={{ color: '#6e8b9e' }}>بحث</Link>
            <Link href="/t/new" className="py-1.5 text-sm" style={{ color: '#6e8b9e' }}>سؤال جديد</Link>
            {user ? (
              <>
                {user.role === 'admin' && (
                  <Link href="/admin" className="py-1.5 text-sm" style={{ color: '#d4a843' }}>لوحة التحكم</Link>
                )}
                <span className="py-1.5 text-sm" style={{ color: '#c8d5de' }}>{user.username}</span>
                <button type="button" onClick={handleLogout} className="py-1.5 text-sm text-right" style={{ color: '#6e8b9e' }}>
                  خروج
                </button>
              </>
            ) : (
              <>
                <Link href="/login" className="py-1.5 text-sm" style={{ color: '#6e8b9e' }}>دخول</Link>
                <Link href="/register" className="py-1.5 text-sm" style={{ color: '#1e8bc3' }}>تسجيل</Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  )
}
