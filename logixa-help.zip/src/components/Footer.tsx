import Link from 'next/link'

export default function Footer() {
  return (
    <footer
      style={{
        background: '#07121b',
        borderTop: '1px solid #163e54',
        textAlign: 'center',
        color: '#3e5a6b',
        fontSize: '12px',
        padding: '16px',
      }}
    >
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-2">
        <div>
          Logixa Help &copy; {new Date().getFullYear()} — منصة الأسئلة والإجابات التقنية
        </div>
        <div className="flex items-center gap-4">
          <Link href="/privacy" style={{ color: '#3e5a6b' }}>سياسة الخصوصية</Link>
          <Link href="/terms" style={{ color: '#3e5a6b' }}>شروط الاستخدام</Link>
          <span>النسخة 1.0</span>
        </div>
      </div>
    </footer>
  )
}
